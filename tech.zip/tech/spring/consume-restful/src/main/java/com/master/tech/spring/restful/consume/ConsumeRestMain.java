package com.master.tech.spring.restful.consume;

import org.springframework.web.client.RestTemplate;

public class ConsumeRestMain {

    public static void main(String[] args) {
        RestTemplate template = new RestTemplate();
        Greeting greeting = template.getForObject("http://localhost:8080/greeting?to=Lily", Greeting.class);
        System.out.println(greeting);
    }

}
