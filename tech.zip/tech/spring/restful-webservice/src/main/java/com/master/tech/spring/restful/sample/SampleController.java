package com.master.tech.spring.restful.sample;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.concurrent.atomic.AtomicLong;

@RestController
public class SampleController {

    private static final String GREETING = "Greeting from %s: Hello, %s !";
    private final AtomicLong counter = new AtomicLong();

    @RequestMapping("/greeting")
    public GreetingPojo greeting(@RequestParam(value = "from", required = false) String from, @RequestParam(value = "to", defaultValue = "World") String to) {
        return new GreetingPojo(counter.incrementAndGet(), from, to, String.format(GREETING, from, to));
    }

}