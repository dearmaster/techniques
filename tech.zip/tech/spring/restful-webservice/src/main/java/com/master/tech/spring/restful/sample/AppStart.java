package com.master.tech.spring.restful.sample;

import org.springframework.boot.SpringApplication;
import org.springframework.context.annotation.ComponentScan;

//@Configuration
//@EnableAutoConfiguration
//@EnableWebMvc
@ComponentScan(basePackages = "com.master.tech.spring.restful.sample")
public class AppStart {

    public static void main(String[] args) {
        SpringApplication.run(AppStart.class, args);
    }

}