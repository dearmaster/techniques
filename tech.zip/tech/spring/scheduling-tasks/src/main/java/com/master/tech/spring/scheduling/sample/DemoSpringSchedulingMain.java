package com.master.tech.spring.scheduling.sample;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class DemoSpringSchedulingMain {

    public static void main(String[] args) {
        new AnnotationConfigApplicationContext(ScheduleTaskConfiguration.class);
    }

}