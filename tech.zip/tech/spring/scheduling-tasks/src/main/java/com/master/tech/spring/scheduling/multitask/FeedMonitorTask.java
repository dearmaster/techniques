package com.master.tech.spring.scheduling.multitask;

import org.springframework.context.annotation.PropertySource;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.text.DateFormat;
import java.util.Date;

@Component
@PropertySource({"classpath:multi-task.properties"})
public class FeedMonitorTask {

    @Scheduled(cron = "${task.schedule.time.feedmonitor}")
    public static void monitor() {
        String time = DateFormat.getDateTimeInstance().format(new Date());
        System.out.println("monitoring feed arrive: " + time);
    }

}