package com.master.tech.spring.scheduling.multitask;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

/**
 * Seems default to be multi-threading when having
 * multi-tasks. Not yet confirmed
 */
public class DemoMultiTaskSchedulingMain {

    public static void main(String[] args) {
        new AnnotationConfigApplicationContext(MultiTaskConfiguration.class);
    }

}