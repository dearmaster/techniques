package com.master.tech.spring.scheduling.sample;

import org.springframework.context.annotation.PropertySource;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.text.DateFormat;
import java.util.Date;

@Component
@PropertySource({"classpath:demo-schedule-task.properties"})
public class DemoTask {

    @Scheduled(cron = "${schedule.time}")
    public void print() {
        String time = DateFormat.getDateTimeInstance().format(new Date());
        System.out.println("current time: " + time);
    }

}