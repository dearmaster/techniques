package com.master.tech.spring.scheduling.multitask;


import org.springframework.context.annotation.PropertySource;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.text.DateFormat;
import java.util.Date;

@Component
@PropertySource("multi-task.properties")
public class DiskUsageTask {

    @Scheduled(cron = "${task.schedule.time.diskusage}")
    public void checkDiskUsage() {
        String time = DateFormat.getDateTimeInstance().format(new Date());
        System.out.println("disk usage check: " + time);
    }

}