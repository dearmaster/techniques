package com.master.core;

public class AntBuildTest {
	
	public static void print() {
		System.out.println("test");
	}
	
	public static void main(String[] args) {
		print();
	}

}